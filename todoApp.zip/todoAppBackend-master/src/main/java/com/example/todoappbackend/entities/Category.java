package com.example.todoappbackend.entities;

public enum Category {
    business,
    personal
}
